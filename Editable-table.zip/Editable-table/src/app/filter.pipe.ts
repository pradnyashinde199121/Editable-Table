import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(obs:any, searchTerm:string): any {
    if (!obs || !searchTerm) {
      return obs;
  }

  return obs.filter(detail =>
    detail.name.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1);
}
  }