import { Component,ViewChild ,ChangeDetectorRef} from '@angular/core';
import {MatTableDataSource, MatPaginator } from '@angular/material';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  Details: any= [
    {
      "_id" : "12323vdfvd234",
      "name" : "Geeta Deshmukh",
      "reg_date" : "2018-04-04",
      "age":26,
      "editable": false
    },
    {
      "_id" : "12323vdfvd234",
      "name" : "Ganesh Jadhav",
      "reg_date" : "2018-04-04",
      "age":26,
      "editable": false
    },
    {
      "_id" : "12323vdfvd234",
      "name" : "Ram Jadhav",
      "reg_date" : "2018-04-04",
      "age":26,
      "editable": false
    },
    {
      "_id" : "12323vdfvd234",
      "name" : "Jay Jadhav",
      "reg_date" : "2018-04-04",
      "age":36,
      "editable": false
    },
    {
      "_id" : "12323vdfvd234",
      "name" : "Deepali Mane",
      "reg_date" : "2018-04-04",
      "age":26,
      "editable": false
    },
    {
      "_id" : "12323vdfvd234",
      "name" : "pooja Jadhav",
      "reg_date" : "2018-04-04",
      "age":24,
      "editable": false
    },
    {
      "_id" : "12323vdfvd234",
      "name" : "Sandip Jadhav",
      "reg_date" : "2018-04-04",
      "age":27,
      "editable": false
    },
    {
      "_id" : "12323vdfvd234",
      "name" : "Ravi Mane",
      "reg_date" : "2019-04-04",
      "age":28,
      "editable": false
    },
    {
      "_id" : "12323vdfvd234",
      "name" : "Geeta Patil",
      "reg_date" : "2018-04-04",
      "age":22,
      "editable": false
    },
    {
      "_id" : "12323vdfvd234",
      "name" : "Ramesh Shinde",
      "reg_date" : "2019-04-04",
      "age":24,
      "editable": false
    }
  ]
  title = 'editable';
  name = 'Angular';
  isVisible : boolean = false;
  //edit:boolean=true;
  dataSource =  new MatTableDataSource(this.Details); 
 @ViewChild(MatPaginator,{static: true}) paginator: MatPaginator; 
 obs: Observable<any>;
 constructor(private changeDetectorRef: ChangeDetectorRef){
 }
 
 ngOnInit() {
  this.dataSource.paginator = this.paginator;
  this.changeDetectorRef.detectChanges();
  this.dataSource.paginator = this.paginator;
  this.obs = this.dataSource.connect();
  };
 

editdetail(detail: any){
    detail.editable = !detail.editable;  
  }
  deleteRow(i){
  this.Details.splice(i,1);
  this.dataSource =  new MatTableDataSource(this.Details);
  this.changeDetectorRef.detectChanges();
  this.dataSource.paginator = this.paginator;
  this.obs = this.dataSource.connect();
}
 
}